# user/__init__.py
from flask import Blueprint, render_template, request, redirect, url_for

# Create the blueprint object.
# The name 'user' is just a reference. __name__ is the module name.
user_routes = Blueprint("user", __name__)

# Define routes under this blueprint.
@user_routes.route("/")
def index():
    return "Welcome to the User Blueprint!"

@user_routes.route("/profile")
def profile():
    return "User profile page."

@user_routes.route("/create", methods=["GET", "POST"])
def create_user():
    if request.method == "POST":
        # Handle form submission or data creation logic
        return redirect(url_for("user.index"))  # Notice how we use "user.index" because that’s the blueprint’s endpoint name
    return render_template("create_user.html")
