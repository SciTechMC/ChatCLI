from flask import Blueprint

test = Blueprint("test", __name__, template_folder="routes")

@test.route('/')
def test():
    return "Hello!"