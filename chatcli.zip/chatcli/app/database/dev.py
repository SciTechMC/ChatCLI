def dev():
    data = {
        "user" : "chatcli_access",
        "password" : "test1234",
        "db" : "chatcli_dev"
    }
    return data