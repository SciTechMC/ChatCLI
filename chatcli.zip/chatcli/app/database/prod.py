def prod():
    data = {
        "user" : "production_chatcli",
        "password" : "S3cret#Code1234",
        "db" : "chatcli_prod"
    }
    return data