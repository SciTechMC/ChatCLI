def email(value = "account"):
    """
    args: value = password/account
    """
    if value == "password":
        return str("itln wqsp pisn bvkq ")
    else:
        return str("chatcli.official@gmail.com")

def db_acc():
    return {"user": "production_chatcli", "password": "S3cret#Code1234", "db" : "chatcli_prod"}