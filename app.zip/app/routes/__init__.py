from chatcli.app.routes.user_routes import user
from chatcli.app.routes.chat_routes import chat
from chatcli.app.routes.base_routes import base

all_blueprints = [user, chat, base]